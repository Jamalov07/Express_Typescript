export const dbConnection = {
  url: "mongodb://localhost:27017/woodline_test",
  options: {
    useNewUrlParser: true,
    useUnifiedTopology: true,
      autoIndex: true,
    //   useCreateIndex: true,
    //   useFindAndModify: false,
  },
};
